db = {'host':'localhost',
      'user':'root',
      'passwd':'dengjia1778$',
      'database':'news_product',
      'charset':'utf8'}

queue = {'host':'localhost',
         'port':'6379',
         'prefix':'news_product_wangyi'}

ts_new = 'new'
ts_inprogress = 'inprogress'
ts_finished = 'finished'


js_new = 'new'
js_failed = 'failed'
js_finished = 'finished'
